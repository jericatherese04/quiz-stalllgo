import React from "react";
import axios from "axios";

const Checkout = ({ orderId }) => {
  const handlePayment = async () => {
    const response = await axios.post("http://127.0.0.1:8000/api/orders/", { orderId });
    window.location.href = response.data.payment_url;
  };

  return (
    <div>
      <h2>Checkout</h2>
      <button onClick={handlePayment}>Pay with PayPal</button>
    </div>
  );
};

export default Checkout;
