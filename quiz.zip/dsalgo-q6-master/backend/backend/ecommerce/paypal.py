import paypalrestsdk

paypalrestsdk.configure({
    "mode": "sandbox",
    "client_id": "YOUR_SANDBOX_CLIENT_ID",
    "client_secret": "YOUR_SANDBOX_SECRET"
})

def create_payment(order):
    payment = paypalrestsdk.Payment({
        "intent": "sale",
        "payer": {"payment_method": "paypal"},
        "transactions": [{
            "amount": {"total": str(order.total_price), "currency": "USD"},
            "description": f"Order {order.id}"
        }],
        "redirect_urls": {
            "return_url": "http://localhost:3000/payment-success",
            "cancel_url": "http://localhost:3000/payment-cancel"
        }
    })
    
    if payment.create():
        return payment["links"][1]["href"]
    return None
