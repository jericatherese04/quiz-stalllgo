from rest_framework import generics, permissions
from rest_framework.response import Response
from .models import Product, Order, Transaction
from .serializers import ProductSerializer, OrderSerializer
from .paypal import create_payment

class ProductListCreate(generics.ListCreateAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
    permission_classes = [permissions.IsAuthenticated]

class OrderCreate(generics.CreateAPIView):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        order = serializer.save(buyer=self.request.user)
        payment_url = create_payment(order)
        return Response({"payment_url": payment_url})
